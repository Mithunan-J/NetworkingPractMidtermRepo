Networking Practical Midterm 
Mithunan Jayaseelan (100787442)
Nathan Moore (100785826)


Step 1: Run the server windows application. It can be found in "NetworkingMidtermServer\NetworkingMidtermServer\bin\Debug".
Step 2: Open the folder "ne3Server build" and run ne3Server.exe. Ingore the name, this is a client unity application.
Step 3: Open the folder "ne3Client build" and run ne3Client.exe. This is also a client unity application.
***It is very important that you log into the server from both clients before moving the cubes.
***Enter "127.0.0.1" into both client log in fields in order to connect to the server.


Controls:
WASD to move cube.

Chat: To use the chat feature, type the message in the chat and then press the send button to send the message to the server.

Quit: To disconnect a client you can:
1. Send the word "quit" (must be lower case) to the server from the chat box.
2. Click the disconnect button.

After a client disconnects, the remaining connected client is still able to move around the scene and send messages to the server. The remaining client's position will still continue to display on the server's console.

Further Notes:
- In the submission, you will find 2 client.cs files. They are 99% identical with the exception of the ports they use.
- You can find both unity client packages in the "ClientPackages" folder.
- Server code can be found in the "ServerCode" folder.
- Client code can be found in the "ClientCode" folder. There are 2 client scripts which are 99% identical except that they use different ports to connect to the server.


